document.getElementById('btn1').addEventListener("click",()=>{




    let num1= Number(document.getElementById('no1').value)

    let num2= Number(document.getElementById('no2').value)


    let sum = num1 + num2
     document.getElementById('sum').innerHTML= '<h1>'+sum+'</h1>'

})

//------------------------------------------------------ 

document.getElementById('btn2').addEventListener("click",()=>{




    let num1= Number(document.getElementById('nom1').value)

    let num2= Number(document.getElementById('nom2').value)

    let num3= Number(document.getElementById('nom3').value)

    let average = (num1 + num2 + num3)/3

     document.getElementById('average').innerHTML= '<h1>'+average+'</h1>'

})
// --------------------------------------------------------
document.getElementById('btn3').addEventListener("click",()=>{




    let num1= Number(document.getElementById('distance').value)

    let num2= Number(document.getElementById('speed').value)


    let time = num1 / num2
     document.getElementById('time').innerHTML= '<h1>'+time+'</h1>'

})
// ------------------------------------------------------------
document.getElementById('btn4').addEventListener("click",()=>{




    let x = Number(document.getElementById('weight').value)

    let y = Number(document.getElementById('height').value)


    let BMI = x / (y*y)
     document.getElementById('BMI').innerHTML= '<h1>'+BMI+'</h1>'

})
// -------------------------------------------------------------
document.getElementById('btn5').addEventListener("click",()=>{




    let x = Number(document.getElementById('cm').value)

    let y = x/100


    let z = y/1000

     document.getElementById('meter').innerHTML= '<h1>'+y+'m'+'</h1>'
     document.getElementById('kilometer').innerHTML= '<h1>'+z+'km'+'</h1>'

})
// ---------------------------------------------------------
document.getElementById('btn6').addEventListener("click",()=>{




    let x = Number(document.getElementById('byte').value)

    let y = x*8


    let z = x/1024

     document.getElementById('bits').innerHTML= '<h1>'+y+'bit'+'</h1>'
     document.getElementById('gigabytes').innerHTML= '<h1>'+z+'giga'+'</h1>'

})
// ----------------------------------------------------------
document.getElementById('btn7').addEventListener("click",()=>{




    let x = Number(document.getElementById('size').value)

    let y = Number(document.getElementById('speed band').value)


    let time = x/y
     document.getElementById('second').innerHTML= '<h1>'+time+'</h1>'

})
// -----------------------------------------------------
document.getElementById('btn8').addEventListener("click",()=>{




    let x = Number(document.getElementById('file size').value)

    let y = Number(document.getElementById('speed bandwidth').value)


    let time = (x*1024)/(y/8)
     document.getElementById('seconds').innerHTML= '<h1>'+time+'s'+'</h1>'

})
// ---------------------------------------------------------------
document.getElementById('btn9').addEventListener("click",()=>{




    let x = Number(document.getElementById('radius').value)

    
let y = 2*(22/7)*x
let z = (22/7)*x*x
   
     document.getElementById('circumference').innerHTML= '<h1>'+y+'</h1>'
     document.getElementById('area of cricle').innerHTML= '<h1>'+z+'</h1>'
})
// --------------------------------------------------------------------
document.getElementById('btn10').addEventListener("click",()=>{




    let num1= Number(document.getElementById('noo1').value)

    let num2= Number(document.getElementById('noo2').value)

    let x = num1
    let y = num2

    num1 = y
    num2 = x
   
     document.getElementById('frist').innerHTML= '<h1>'+'number one is'+' '+num1+'</h1>'
     document.getElementById('the second').innerHTML= '<h1>'+'number two is'+' '+num2+'</h1>'

})
// -----------------------------------------------------------------
